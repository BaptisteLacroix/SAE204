insert into connection (idConnection)
values (1);
insert into connection (idConnection)
values (2);
insert into connection (idConnection)
values (3);
insert into connection (idConnection)
values (4);
insert into connection (idConnection)
values (5);
insert into connection (idConnection)
values (6);
insert into connection (idConnection)
values (7);
insert into connection (idConnection)
values (8);
insert into connection (idConnection)
values (9);
insert into connection (idConnection)
values (10);
insert into connection (idConnection)
values (11);
insert into connection (idConnection)
values (12);
insert into connection (idConnection)
values (13);
insert into connection (idConnection)
values (14);
insert into connection (idConnection)
values (15);
insert into connection (idConnection)
values (16);
insert into connection (idConnection)
values (17);
insert into connection (idConnection)
values (18);
insert into connection (idConnection)
values (19);
insert into connection (idConnection)
values (20);
insert into connection (idConnection)
values (21);
insert into connection (idConnection)
values (22);
insert into connection (idConnection)
values (23);
insert into connection (idConnection)
values (24);
insert into connection (idConnection)
values (25);
insert into connection (idConnection)
values (26);
insert into connection (idConnection)
values (27);
insert into connection (idConnection)
values (28);
insert into connection (idConnection)
values (29);
insert into connection (idConnection)
values (30);
insert into connection (idConnection)
values (31);
insert into connection (idConnection)
values (32);
insert into connection (idConnection)
values (33);
insert into connection (idConnection)
values (34);
insert into connection (idConnection)
values (35);
insert into connection (idConnection)
values (36);
insert into connection (idConnection)
values (37);
insert into connection (idConnection)
values (38);
insert into connection (idConnection)
values (39);
insert into connection (idConnection)
values (40);
insert into connection (idConnection)
values (41);
insert into connection (idConnection)
values (42);
insert into connection (idConnection)
values (43);
insert into connection (idConnection)
values (44);
insert into connection (idConnection)
values (45);
insert into connection (idConnection)
values (46);
insert into connection (idConnection)
values (47);
insert into connection (idConnection)
values (48);
insert into connection (idConnection)
values (49);
insert into connection (idConnection)
values (50);

insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (1, '18320 Hooker Park', '74100', '3316327711', 'kallabush0@csmonitor.com', 'Snkf9cPmHkEj', 1, 1,
        'Duis mattis egestas metus.', 2999.1, 3273, 2611, 79, 2322, 58.35, 349, 1.5, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (2, '6297 Union Park', '51140', '4478879128', 'jlabrone1@trellian.com', 'Tuj5wyNT3', 1, 2,
        'Integer tincidunt ante vel ipsum.', 3246.79, 2629, 4, 56, 618, 50.0, 471, 4.0, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (3, '37020 Fairview Plaza', '39210', '7685209670', 'kposthill2@wiley.com', 'l9A6RhExR', 0, 3,
        'Suspendisse potenti.', 2554.1, 1584, 1709, 87, 1693, 79.34, 73, 0.5, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (4, '53 Eastlawn Lane', '28120', '3927750733', 'wpervew3@slashdot.org', 'PPm45kFUlhin', 1, 4, 'Etiam justo.',
        707.93, 4727, 4297, 75, 1467, 11.5, 153, 4.3, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (5, '2 Dorton Road', '14230', '5824325796', 'bjakoubek4@umn.edu', 'tYH58iPg', 1, 5,
        'In hac habitasse platea dictumst.', 480.04, 2685, 1585, 71, 402, 58.73, 124, 3.6, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (6, '57430 Spenser Place', '31700', '4022867455', 'rsancroft5@google.fr', 'IRZPONEwrP', 0, 6,
        'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 680.61, 2168, 3904, 13, 1899, 27.83, 105, 4.4,
        0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (7, '0 Buhler Circle', '60240', '1642768633', 'nblaszczynski6@netvibes.com', 'CpA24eGUqI', 0, 7,
        'Praesent blandit.', 1643.26, 268, 1228, 84, 1177, 93.67, 1, 4.2, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (8, '4 Charing Cross Pass', '31160', '6726465635', 'wmiddlehurst7@buzzfeed.com', 'phE2JxYyy0K', 0, 8,
        'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 680.27, 1071, 2293, 64, 1685, 0.93,
        375, 0.7, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (9, '80 Johnson Drive', '23160', '7725892776', 'nmoar8@desdev.cn', '3cJE8p', 0, 9, 'Donec ut dolor.', 4096.62,
        2695, 1582, 84, 1702, 1.32, 32, 3.3, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (10, '060 Fairfield Lane', '21610', '8251659018', 'mpinar9@tumblr.com', '0URED3Lox8', 1, 10,
        'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices',
        337.52, 4045, 2230, 73, 485, 52.61, 227, 3.0, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (11, '96417 Truax Court', '16700', '7719758097', 'alawsa@tiny.cc', 'y5er5WBixr', 0, 11,
        'Pellentesque eget nunc.', 2971.67, 3792, 1356, 78, 779, 69.34, 240, 2.4, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (12, '519 Lighthouse Bay Trail', '25190', '7062832509', 'ntantumb@over-blog.com', 'w53Aoq3t', 1, 12,
        'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.',
        1489.7, 4566, 1524, 37, 431, 11.82, 386, 3.0, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (13, '70 Lotheville Crossing', '59152', '2582060530', 'mastallc@weather.com', 'Za7qhNI', 1, 13,
        'Pellentesque ultrices mattis odio.', 2422.25, 1780, 4371, 91, 1894, 29.9, 468, 4.9, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (14, '961 Elka Hill', '26510', '1482679369', 'bsuddickd@quantcast.com', 'LzzngxnXO', 1, 14,
        'Aliquam sit amet diam in magna bibendum imperdiet.', 2684.71, 2246, 4935, 61, 1591, 90.33, 431, 0.4, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (15, '29291 Burning Wood Park', '60810', '9553524989', 'ebickerstaffee@zimbio.com', 'IOhQI2OJWC', 0, 15,
        'Nulla tellus.', 2063.78, 3537, 1839, 54, 1471, 41.03, 60, 3.5, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (16, '3073 Gina Parkway', '31480', '8646692858', 'fdekeyserf@aboutads.info', 'nHvaXMDL7iAL', 0, 16,
        'Vestibulum rutrum rutrum neque.', 2861.02, 4724, 2589, 22, 419, 55.29, 442, 3.7, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (17, '5964 Westerfield Avenue', '49350', '9495183992', 'rmaccarig@china.com.cn', 'IciVG7EZ', 1, 17,
        'Proin risus.', 27.78, 2087, 4556, 0, 1939, 32.86, 195, 2.2, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (18, '0307 Burning Wood Trail', '65150', '1396683874', 'bkildaleh@w3.org', 'wrA3oSkiqb6', 0, 18,
        'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 1006.35, 3494, 3514, 18, 2435, 37.0,
        253, 1.8, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (19, '7 Northview Parkway', '15190', '3289446753', 'sbengtssoni@plala.or.jp', 'lRxLePJ63', 1, 19,
        'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 1384.6, 4818, 458, 79, 1187, 77.89,
        100, 4.8, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (20, '04449 West Hill', '27940', '9996397753', 'cbaldacchinoj@dropbox.com', 'lBU0WKaI', 1, 20,
        'Ut at dolor quis odio consequat varius.', 1456.44, 2511, 3897, 90, 2709, 6.98, 4, 1.0, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (21, '2 Southridge Trail', '27480', '5625180377', 'cwedmorek@domainmarket.com', 'LN0x7jCf', 0, 21,
        'Donec ut mauris eget massa tempor convallis.', 2059.2, 1941, 3136, 84, 2154, 80.05, 212, 3.1, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (22, '919 Transport Circle', '25170', '5331308078', 'kspirel@reuters.com', 'mk9tzqoG4', 1, 22,
        'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.', 1352.82, 4508, 3967, 43, 843, 43.52, 16,
        1.4, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (23, '5676 Darwin Point', '89630', '1147309881', 'lbedburym@bing.com', 'zS6I7kn4iW', 1, 23,
        'Proin at turpis a pede posuere nonummy.', 2563.92, 1014, 1743, 48, 532, 33.82, 494, 0.8, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (24, '264 Oriole Court', '22100', '4401230895', 'csilcockn@ning.com', 'bFHtlcy73h5R', 0, 24,
        'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 149.88, 2280, 834, 55, 2595, 26.94,
        307, 4.9, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (25, '24506 Milwaukee Alley', '77148', '9456204502', 'soldacreso@salon.com', 'PuOZjD', 0, 25, 'Vivamus tortor.',
        144.57, 3605, 1253, 91, 2396, 68.6, 296, 4.5, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (26, '036 Crescent Oaks Place', '53440', '3364980187', 'mghidottip@yellowpages.com', 'jZKIRt', 0, 26,
        'Morbi non lectus.', 693.45, 2939, 2263, 1, 1723, 8.09, 174, 4.3, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (27, '02 Blue Bill Park Street', '33220', '8552444195', 'ebenediktssonq@ucoz.com', 'WBSH1sUrYC8j', 1, 27,
        'Nulla ac enim.', 4135.14, 705, 1018, 34, 797, 37.81, 28, 0.3, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (28, '442 Crescent Oaks Place', '22350', '7756028629', 'hcarrierr@pcworld.com', 'm2wqIYjIR4Uk', 1, 28,
        'Phasellus id sapien in sapien iaculis congue.', 726.15, 112, 4969, 65, 2723, 28.31, 348, 2.7, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (29, '401 Jenifer Place', '23100', '9907044471', 'rharknesss@moonfruit.com', 'AvmNlD', 0, 29,
        'Integer non velit.', 511.81, 2175, 2664, 68, 2235, 17.21, 271, 0.6, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (30, '74 Bartillon Point', '21110', '6342064314', 'bwoodesont@youku.com', 'uocqvt1gg7', 1, 30,
        'Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante.',
        3633.08, 1840, 2107, 61, 2004, 48.97, 236, 4.1, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (31, '65 Sunfield Point', '65440', '4858711835', 'fsilversonu@scribd.com', 'qKz0IZ', 0, 31, 'Morbi non lectus.',
        2991.55, 440, 990, 90, 1760, 31.89, 282, 1.3, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (32, '6 Del Mar Parkway', '28320', '9027708093', 'hmatuszynskiv@answers.com', 'wu2ODR', 0, 32,
        'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio.',
        697.85, 1172, 1825, 28, 913, 43.89, 478, 0.2, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (33, '8530 Judy Lane', '45740', '9853289188', 'wgallagherw@pinterest.com', '5w9gPNJCM2Gw', 0, 33,
        'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.', 3302.45, 1465, 2109, 4, 1462, 97.56, 415,
        2.9, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (34, '86578 Drewry Pass', '47600', '1336798820', 'odalmanx@cbsnews.com', 'lreKLT15P', 1, 34,
        'Morbi quis tortor id nulla ultrices aliquet.', 1364.76, 2878, 1079, 73, 2847, 34.19, 236, 3.7, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (35, '4611 Brown Way', '77170', '1461355866', 'igiacobelliy@rakuten.co.jp', 'zCnD98', 0, 35,
        'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo.', 2135.81, 881, 1307, 5, 611, 11.53,
        374, 4.6, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (36, '6 Sage Avenue', '52300', '6091434965', 'ksainsburyz@mail.ru', '3tMLrd7Z', 1, 36, 'Praesent lectus.',
        2343.23, 4618, 2934, 79, 327, 25.29, 63, 4.3, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (37, '8215 Ruskin Plaza', '85120', '5365788627', 'slightbown10@kickstarter.com', 'Q20vid', 1, 37,
        'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 4249.72, 2349, 1704, 81, 521, 23.67, 194,
        0.2, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (38, '67655 Meadow Valley Center', '50800', '3219829107', 'bcoxwell11@dion.ne.jp', 'lUSTQu1KDoyP', 1, 38,
        'Pellentesque ultrices mattis odio.', 1513.78, 61, 244, 42, 2204, 49.29, 49, 2.2, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (39, '69891 Kenwood Way', '70130', '3282728623', 'kadger12@zimbio.com', '1JG7tW', 0, 39, 'Integer non velit.',
        4978.59, 1328, 2809, 54, 1277, 42.78, 474, 1.2, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (40, '7562 Eggendart Plaza', '68220', '8952102137', 'adufore13@sogou.com', 'iPH6aFTN', 1, 40, 'Nulla facilisi.',
        546.47, 1236, 3609, 42, 2082, 1.57, 165, 3.2, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (41, '302 Delaware Circle', '17400', '9163860330', 'ksausman14@bing.com', '5aPNuyD7z', 0, 41,
        'Maecenas rhoncus aliquam lacus.', 1628.38, 1576, 66, 15, 408, 78.5, 13, 3.9, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (42, '0 American Ash Hill', '54480', '4236662150', 'amaevela15@springer.com', 'CESdc1NlH', 0, 42,
        'Aliquam erat volutpat.', 479.87, 4012, 4304, 15, 1349, 87.18, 123, 0.2, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (43, '33 Lawn Crossing', '86200', '2021724046', 'fparry16@live.com', '4xC2XatUgNjZ', 0, 43,
        'Duis at velit eu est congue elementum.', 4271.24, 1283, 210, 81, 676, 90.12, 170, 0.0, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (44, '58626 Manufacturers Pass', '65500', '4371653472', 'rcallear17@jimdo.com', 'PYlJ6Jl', 1, 44,
        'Proin at turpis a pede posuere nonummy.', 4972.82, 4745, 1051, 19, 249, 54.83, 209, 2.5, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (45, '62155 Norway Maple Lane', '28120', '3738816963', 'dmarriott18@mysql.com', 'a8onVWL', 0, 45,
        'Nullam sit amet turpis elementum ligula vehicula consequat.', 2484.45, 984, 11, 3, 1944, 23.4, 480, 0.4, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (46, '3575 Union Drive', '13370', '3482143011', 'gplenty19@yelp.com', '9V9zzRa', 1, 46, 'Nam dui.', 1126.3, 2573,
        698, 73, 963, 22.07, 119, 3.3, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (47, '007 Novick Avenue', '80290', '7845100414', 'rceresa1a@dedecms.com', '2Fr2RhNs', 0, 47,
        'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante.', 3307.39, 2554, 3960, 59, 585, 32.62,
        440, 3.8, 1);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (48, '74 Oakridge Alley', '46330', '4238665007', 'dmarchetti1b@sogou.com', '0hNNozST3jaG', 1, 48, 'Nunc nisl.',
        4077.36, 2966, 4752, 4, 2746, 68.29, 8, 1.3, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (49, '951 7th Court', '60210', '9378993952', 'abaudichon1c@unicef.org', 'PBbfMwC', 0, 49,
        'Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 384.07, 2149, 3942, 41, 1206, 60.27,
        58, 3.8, 0);
insert into utilisateur (idUtilisateur, adresse, codePostal, mobile, adresseMail, motDePasse, infoPartenaire,
                         idConnection, biographie, solde, totalVente, totalAchat, nbrDemandes, delayMoyenReponse,
                         tauxReponse, nbrAvisTotal, moyenneNotes, abonnement)
values (50, '7 Delaware Place', '32810', '2037040005', 'awoliter1d@ocn.ne.jp', 'ZmOl9X8y', 0, 50,
        'Mauris ullamcorper purus sit amet nulla.', 4443.87, 1439, 1471, 74, 653, 51.24, 256, 2.7, 1);

insert into utilisateurParticulier
values (1, 'Bone', 'Bartels');
insert into utilisateurParticulier
values (2, 'Diannne', 'Letson');
insert into utilisateurParticulier
values (3, 'Maggi', 'Truesdale');
insert into utilisateurParticulier
values (4, 'Quill', 'Reveley');
insert into utilisateurParticulier
values (5, 'Shalom', 'Le Borgne');
insert into utilisateurParticulier
values (6, 'Jannelle', 'Winter');
insert into utilisateurParticulier
values (7, 'Margette', 'Jeffcock');
insert into utilisateurParticulier
values (8, 'Sherie', 'Pessolt');
insert into utilisateurParticulier
values (9, 'Lynne', 'Alner');
insert into utilisateurParticulier
values (10, 'Bruis', 'Joblin');

insert into utilisateurEntreprise
values (11, 'Reading International Inc', 'Grocery');
insert into utilisateurEntreprise
values (12, 'New York & Company, Inc.', 'Sports');
insert into utilisateurEntreprise
values (13, 'XPO Logistics, Inc.', 'Clothing');
insert into utilisateurEntreprise
values (14, 'Town Sports International Holdings, Inc.', 'Garden');
insert into utilisateurEntreprise
values (15, 'Monster Beverage Corporation', 'Outdoors');
insert into utilisateurEntreprise
values (16, 'Alere Inc.', 'Jewelry');
insert into utilisateurEntreprise
values (17, 'Gabelli NextShares Trust', 'Home');
insert into utilisateurEntreprise
values (18, 'Melrose Bancorp, Inc.', 'Computers');
insert into utilisateurEntreprise
values (19, 'AudioCodes Ltd.', 'Books');
insert into utilisateurEntreprise
values (20, 'Capital Senior Living Corporation', 'Home');

insert into utilisateurEntrepreneur
values (21, 'Gris', 'Hirschmann', '8x8 Inc', 'Toys');
insert into utilisateurEntrepreneur
values (22, 'Alfi', 'Garfirth', 'Gabelli Global Small and Mid Cap Value Trust (The)', 'Jewelry');
insert into utilisateurEntrepreneur
values (23, 'Janis', 'Smeaton', 'First Trust Indxx Global Natural Resources Income', 'Kids');
insert into utilisateurEntrepreneur
values (24, 'Siegfried', 'Lucks', 'Allete, Inc.', 'Shoes');
insert into utilisateurEntrepreneur
values (25, 'Kipp', 'Jacobowitz', 'John Hancock Income Securities Trust', 'Garden');
insert into utilisateurEntrepreneur
values (26, 'Merl', 'Robinette', 'FireEye, Inc.', 'Books');
insert into utilisateurEntrepreneur
values (27, 'Nicolea', 'Scallan', 'Two River Bancorp', 'Home');
insert into utilisateurEntrepreneur
values (28, 'Raven', 'Justham', 'Barnes & Noble, Inc.', 'Games');
insert into utilisateurEntrepreneur
values (29, 'Steven', 'Leyden', 'GigaMedia Limited', 'Jewelry');
insert into utilisateurEntrepreneur
values (30, 'Elroy', 'Okroy', 'First Financial Bancorp.', 'Movies');

insert into utilisateurAssociation
values (31, 'Johannah', 'Birchett', 'Supernus Pharmaceuticals, Inc.');
insert into utilisateurAssociation
values (32, 'Daffy', 'Verriour', 'FARO Technologies, Inc.');
insert into utilisateurAssociation
values (33, 'Lanna', 'Shilstone', 'General Dynamics Corporation');
insert into utilisateurAssociation
values (34, 'Zebedee', 'Clissell', 'Edwards Lifesciences Corporation');
insert into utilisateurAssociation
values (35, 'Duke', 'Knightley', 'Planet Fitness, Inc.');
insert into utilisateurAssociation
values (36, 'Libby', 'Kalaher', 'Putnam Premier Income Trust');
insert into utilisateurAssociation
values (37, 'Milt', 'Booeln', 'Socket Mobile, Inc.');
insert into utilisateurAssociation
values (38, 'Ardine', 'Walesa', 'Fidelity National Financial, Inc.');
insert into utilisateurAssociation
values (39, 'Eva', 'Lighterness', 'United Rentals, Inc.');
insert into utilisateurAssociation
values (40, 'Florencia', 'Stanbra', 'United Dominion Realty Trust, Inc.');


insert into avis
values (1,
        'N"a pas hésité à me rendre service même s"il ne pouvait pas vraiment m"aider sur la forme ! En deux coups de fil mon problème était réglé ',
        5, 25);
insert into avis
values (2, 'Personne de confiance,  ponctuel  aimable .', 5, 49);
insert into avis
values (3, 'Evaluation automatique : Marché conclu avec succès !!', 5, 21);
insert into avis
values (4, 'Excellent travail du début jusqu’à la fin à des prix raisonnables et compétitifs. je recommande à 200%', 5,
        1);
insert into avis
values (6,
        'Il est venu quasiment immédiatement et a fait le travail très rapidement et avec sérieux... je le recommande vivement',
        5, 26);
insert into avis
values (8,
        'Très sérieux, compétent, de toute confiance heureuse d"avoir pu compter sur lui ,pour un démontage et je ferai de nouveau appel à lui en cas de besoin sans hésiter',
        5, 39);
insert into avis
values (10, 'Très bon travail personne sympathique très satisfaite de la prestation.', 5, 12);
insert into avis
values (11, 'Tout c’est parfaitement déroulé, très sympathique et professionnel! Je le recommande a tous!',
        5, 42);
insert into avis
values (12, 'Au top ! Serviable et ponctuel', 5, 19);
insert into avis
values (13,
        'Il a  chargé un abri de jardin en kit de la maison dans une camionnette, sans difficulté, sur le temps estimé',
        5, 36);
insert into avis
values (14,
        'Le déménagement s"est déroulé à la perfection, très sympathique, ponctuel et minutieux dans ce qu"il fait. Je le recommande à 100% et ferai de nouveau appel à ses services.',
        5, 36);
insert into avis
values (15,
        'Ponctuel, sympathique et souriant. Il donne le meilleur de lui même. Il tient ses délais et ses engagements. Je recommande vivement Stéphane!',
        5, 38);
insert into avis
values (16, 'Ponctuel et efficace. Du très bon boulot. Je n"hésiterai pas à faire à nouveau appel à lui.', 5, 27);
insert into avis
values (17, 'Excellent! Je ferai appel à lui dans le futur. Je recommande.', 5, 11);
insert into avis
values (18,
        'Le déménagement s’est très bien passé grâce à Stephane et à son ami Momo. Si vous cherchez des gars costauds contactez-les !',
        5, 1);
insert into avis
values (19,
        'Très ponctuel, gentil et serviable, et hyper efficace pour mon déménagement. Je le recommande les yeux fermés ! Merci !',
        5, 15);
insert into avis
values (20, 'Super déménagement ! Tout s’est hyper bien passé, très sympas, ponctuel et professionnel', 5, 17);
insert into avis
values (21, 'Très sympathique, et bon bricoleur m"a bien aidé  sur mon intervention, très bon voisin',4,21);

insert into avis values (22, 'Merci. on aura l"occasion de se revoir pour la voiture de mon épouse.', 5, 22);

insert into avis
values (23, 'Personne sérieuse est fiable', 5, 23);

insert into avis
values (24, 'Très bon travail à prix correct', 5, 24);

insert into avis
values (25, 'J’ai payé ce monsieur en partant en week-end, je suis revenu c’était un travail de margoulins ni fait ni à faire. Je l ai rappelé à mon retour et injoignable .c est un escroc', 1, 25);


insert into administrateur (idAdministrateur)
values (1);
insert into administrateur (idAdministrateur)
values (2);
insert into administrateur (idAdministrateur)
values (3);
insert into administrateur (idAdministrateur)
values (4);
insert into administrateur (idAdministrateur)
values (5);
insert into administrateur (idAdministrateur)
values (6);
insert into administrateur (idAdministrateur)
values (7);
insert into administrateur (idAdministrateur)
values (8);
insert into administrateur (idAdministrateur)
values (9);
insert into administrateur (idAdministrateur)
values (10);

insert into vendeur (idVendeur)
values (11);
insert into vendeur (idVendeur)
values (12);
insert into vendeur (idVendeur)
values (13);
insert into vendeur (idVendeur)
values (14);
insert into vendeur (idVendeur)
values (15);
insert into vendeur (idVendeur)
values (16);
insert into vendeur (idVendeur)
values (17);
insert into vendeur (idVendeur)
values (18);
insert into vendeur (idVendeur)
values (19);
insert into vendeur (idVendeur)
values (20);

insert into clients (idClient)
values (21);
insert into clients (idClient)
values (22);
insert into clients (idClient)
values (23);
insert into clients (idClient)
values (24);
insert into clients (idClient)
values (25);
insert into clients (idClient)
values (26);
insert into clients (idClient)
values (27);
insert into clients (idClient)
values (28);
insert into clients (idClient)
values (29);
insert into clients (idClient)
values (30);

insert into clients (idClient)
values (31);
insert into vendeur (idVendeur)
values (32);
insert into ADMINISTRATEUR (idAdministrateur)
values (33);
insert into clients (idClient)
values (34);
insert into vendeur (idVendeur)
values (35);
insert into clients (idClient)
values (36);
insert into vendeur (idVendeur)
values (37);
insert into ADMINISTRATEUR (idAdministrateur)
values (38);
insert into clients (idClient)
values (39);
insert into vendeur (idVendeur)
values (40);

insert into clients (idClient)
values (41);
insert into vendeur (idVendeur)
values (42);
insert into ADMINISTRATEUR (idAdministrateur)
values (43);
insert into clients (idClient)
values (44);
insert into vendeur (idVendeur)
values (45);
insert into clients (idClient)
values (46);
insert into vendeur (idVendeur)
values (47);
insert into ADMINISTRATEUR (idAdministrateur)
values (48);
insert into clients (idClient)
values (49);
insert into vendeur (idVendeur)
values (50);

insert into administrateur (idAdministrateur)
values (11);
insert into clients (idClient)
values (2);
insert into vendeur (idVendeur)
values (3);
insert into administrateur (idAdministrateur)
values (14);
insert into clients (idClient)
values (5);
insert into vendeur (idVendeur)
values (6);
insert into administrateur (idAdministrateur)
values (17);
insert into clients (idClient)
values (8);
insert into vendeur (idVendeur)
values (9);
insert into administrateur (idAdministrateur)
values (20);

insert into administrateur (idAdministrateur)
values (21);
insert into clients (idClient)
values (3);
insert into vendeur (idVendeur)
values (23);
insert into administrateur (idAdministrateur)
values (24);
insert into clients (idClient)
values (4);
insert into vendeur (idVendeur)
values (26);
insert into administrateur (idAdministrateur)
values (27);
insert into clients (idClient)
values (7);
insert into vendeur (idVendeur)
values (29);
insert into administrateur (idAdministrateur)
values (30);

insert into administrateur (idAdministrateur)
values (31);
insert into clients (idClient)
values (12);
insert into vendeur (idVendeur)
values (43);
insert into administrateur (idAdministrateur)
values (34);
insert into clients (idClient)
values (15);
insert into vendeur (idVendeur)
values (46);
insert into administrateur (idAdministrateur)
values (37);
insert into clients (idClient)
values (18);
insert into vendeur (idVendeur)
values (49);
insert into administrateur (idAdministrateur)
values (40);

insert into planning
values (1, '18/10/2021', 3);
insert into planning
values (2, '27/05/2022', 6);
insert into planning
values (3, '26/09/2021', 9);
insert into planning
values (4, '22/12/2021', 11);
insert into planning
values (5, '02/07/2021', 12);
insert into planning
values (6, '18/02/2022', 13);
insert into planning
values (7, '11/07/2021', 14);
insert into planning
values (8, '13/06/2021', 15);
insert into planning
values (9, '16/07/2021', 16);
insert into planning
values (10, '29/04/2022', 17);
insert into planning
values (11, '16/05/2021', 18);
insert into planning
values (12, '06/04/2021', 19);
insert into planning
values (13, '17/12/2021', 20);
insert into planning
values (14, '08/02/2021', 23);
insert into planning
values (15, '24/04/2021', 26);
insert into planning
values (16, '06/08/2022', 29);
insert into planning
values (17, '10/05/2021', 32);
insert into planning
values (18, '22/04/2021', 35);
insert into planning
values (19, '03/10/2022', 37);
insert into planning
values (20, '18/01/2021', 40);
insert into planning
values (21, '16/09/2022', 42);
insert into planning
values (22, '27/09/2022', 43);
insert into planning
values (23, '13/11/2022', 45);
insert into planning
values (24, '16/04/2021', 46);
insert into planning
values (25, '05/01/2022', 47);
insert into planning
values (26, '31/03/2022', 49);
insert into planning
values (27, '16/04/2022', 50);

SELECT * FROM CLIENTS;
SELECT * FROM PLANNING;

insert into reservation
values (1, 0, 1, 2);
insert into reservation
values (2, 0, 2, 3);
insert into reservation
values (3, 1, 3, 4);
insert into reservation
values (4, 0, 4, 5);
insert into reservation
values (5, 1, 5, 7);
insert into reservation
values (6, 1, 6, 8);
insert into reservation
values (7, 1, 7, 12);
insert into reservation
values (8, 0, 8, 15);
insert into reservation
values (9, 0, 9, 18);
insert into reservation
values (10, 0, 10, 21);
insert into reservation
values (11, 1, 11, 22);
insert into reservation
values (12, 0, 12, 23);
insert into reservation
values (13, 1, 13, 24);
insert into reservation
values (14, 1, 14, 25);
insert into reservation
values (15, 0, 15, 26);
insert into reservation
values (16, 1, 16, 27);
insert into reservation
values (17, 1, 17, 28);
insert into reservation
values (18, 1, 18, 29);
insert into reservation
values (19, 1, 19, 30);
insert into reservation
values (20, 0, 20, 31);
insert into reservation
values (21, 0, 21, 34);
insert into reservation
values (22, 0, 22, 36);
insert into reservation
values (23, 1, 23, 39);
insert into reservation
values (24, 1, 24, 41);
insert into reservation
values (25, 0, 25, 44);
insert into reservation
values (26, 1, 26, 46);
insert into reservation
values (27, 0, 27, 49);

insert into categorie
values (1, 'Bricolage - Travaux');
insert into categorie
values (2, 'Jardinage - Piscine');
insert into categorie
values (3, 'Demenagement - Manutention');
insert into categorie
values (4, 'Depannage - Reparation de materiel');
insert into categorie
values (5, 'Entretien - Reparation vehicules');
insert into categorie
values (6, 'Services vehicules');
insert into categorie
values (7, 'Services a la personne');
insert into categorie
values (8, 'Enfants');
insert into categorie
values (9, 'Animaux');
insert into categorie
values (10, 'Informatique et web');
insert into categorie
values (11, 'Photographie - Video');
insert into categorie
values (12, 'Animation - Evenements');
insert into categorie
values (13, 'Cours - Formations');
insert into categorie
values (14, 'Administratif - Bureautique');
insert into categorie
values (15, 'Mode - Sante - Bien etre');
insert into categorie
values (16, 'Sport - Partenaires');
insert into categorie
values (17, 'Restauration - Reception');
insert into categorie
values (18, 'Outillage & Travaux');
insert into categorie
values (19, 'Materiel de Jardin');
insert into categorie
values (20, 'Maison & Confort');
insert into categorie
values (21, 'Evenement, Reception & Fete');
insert into categorie
values (22, 'High Tech & Fournitures de bureau');
insert into categorie
values (23, 'Materiel de Sport');
insert into categorie
values (24, 'Loisirs');
insert into categorie
values (25, 'Mode & Accessoires Adulte, Bien-etre & Bagagerie');
insert into categorie
values (26, 'Mode Enfant, Bebe & Puericulture');
insert into categorie
values (27, 'Transport & Accessoires Auto, Moto & Bateau');
insert into categorie
values (28, 'Immobilier');


insert into localisation
values (1, '079 Canary Road', '57340', 'Brulange');
insert into localisation
values (2, '6994 Jenifer Hill', '62120', 'Blessy');
insert into localisation
values (3, '4136 Harper Terrace', '62157', 'Allouagne');
insert into localisation
values (4, '0997 Warbler Plaza', '91720', 'Maisse');
insert into localisation
values (5, '99 Veith Trail', '70110', 'Villersexel');
insert into localisation
values (6, '4 Westridge Avenue', '43170', 'Saugues');
insert into localisation
values (7, '56 Brickson Park Plaza', '25640', 'Chaudefontaine');
insert into localisation
values (8, '75188 Mcguire Plaza', '83500', 'La Seyne-sur-Mer');
insert into localisation
values (9, '4694 Claremont Road', '14510', 'Houlgate');
insert into localisation
values (10, '67523 Brickson Park Road', '49600', 'Andreze');
insert into localisation
values (11, '1 Mendota Street', '82120', 'Lavit');
insert into localisation
values (12, '58 Sommers Drive', '35150', 'Corps Nuds');
insert into localisation
values (13, '4 Independence Way', '45290', 'Les Choux');
insert into localisation
values (14, '5 Manley Parkway', '11220', 'Lagrasse');
insert into localisation
values (15, '9 Delladonna Trail', '71290', 'Simandre');
insert into localisation
values (16, '609 Jackson Park', '42170', 'Chambles');
insert into localisation
values (17, '88 Vera Junction', '83100', 'Toulon');
insert into localisation
values (18, '21 Linden Parkway', '11230', 'Puivert');
insert into localisation
values (19, '26 Rowland Plaza', '17210', 'Chevanceaux');
insert into localisation
values (20, '57 Waxwing Parkway', '16700', 'Ruffec');
insert into localisation
values (21, '84 Waubesa Drive', '60310', 'Candor');
insert into localisation
values (22, '42876 Grim Alley', '27350', 'Brestot');
insert into localisation
values (23, '6 Stone Corner Center', '48100', 'Marvejols');
insert into localisation
values (24, '98 Forest Dale Circle', '91170', 'Viry Chatillon');
insert into localisation
values (25, '49 Chive Plaza', '33190', 'Blaignac');
insert into localisation
values (26, '24547 Nelson Park', '67700', 'Saverne');
insert into localisation
values (27, '85 Mesta Court', '25190', 'Fleurey');

insert into bien
values (1, 'LOCATION', 'Outillage & Travaux', 5.64, 'Vente d"outils', 12, 25, 35, 18);
insert into bien
values (2, 'LOCATION', 'Outillage & Entretien', 2.99, 'Entretien d"outils', 23, 19, 45, 18);
insert into bien
values (3, 'EMPRUNT', 'BTP & Chantier', 0, 'Travaux', 20, 1, 42, 1);
insert into bien
values (4, 'LOCATION', 'Elevation & Echafaudage', 40.50, 'echafauddage en location', 18, 18, 47, 1);
insert into bien
values (5, 'EMPRUNT', 'Chauffage & Climatisation', 0, 'Climatisation a faire', 4, 9, 16, 1);
insert into bien
values (6, 'LOCATION', 'Mesure & Detection', 1.99, 'Detection de fuites', 11, 24, 14, 1);
insert into bien
values (7, 'EMPRUNT', 'Manutention', 0, 'Manutention', 16, 27, 43, 3);
insert into bien
values (8, 'EMPRUNT', 'Equipement de protection de la personne', 0, 'pret de casques de chantiers', 24, 15, 20, 7);
insert into bien
values (9, 'LOCATION', 'Materiel de Jardin', 780.99, 'tondeuse en locaton', 14, 21, 37, 2);
insert into bien
values (10, 'EMPRUNT', 'Outillage', 0, 'Outils', 21, 26, 29, 18);
insert into bien
values (11, 'LOCATION', 'Equipement & Piscine', 259.54, 'Piscine a louer', 1, 20, 40, 1);
insert into bien
values (12, 'LOCATION', 'Barbecue & Cuisine exterieur', 5.64, 'barbecue', 9, 11, 46, 20);
insert into bien
values (13, 'LOCATION', 'Decoration exterieur', 12.89, 'Decoration exterieur', 17, 12, 3, 19);
insert into bien
values (14, 'LOCATION', 'Eco-paturage', 56.24, 'paturage', 26, 8, 13, 9);
insert into bien
values (15, 'EMPRUNT', 'Maison & Confort', 0, 'Confort', 2, 5, 26, 20);
insert into bien
values (16, 'LOCATION', 'Electromenager', 52.36, 'Electromenager', 15, 13, 49, 20);
insert into bien
values (17, 'EMPRUNT', 'Vaisselle, Ustensiles de cuisine', 0, 'Vaisselle', 8, 4, 12, 20);
insert into bien
values (18, 'LOCATION', 'Ameublement, Accessoires', 483.25, 'Ameublement', 6, 3, 32, 28);
insert into bien
values (19, 'LOCATION', 'Linge de maison', 12.68, 'Linge', 22, 2, 50, 20);
insert into bien
values (20, 'LOCATION', 'Materiel medical', 1025.99, 'Materiel', 3, 6, 19, 15);

insert into services
values (1, 'Bricolage - Petits travaux', 5, ' Petits travaux', 7, 18, 46, 18);
insert into services
values (2, 'Montage meubles en kit', 6, 'Montage meubles', 2, 13, 37, 7);
insert into services
values (3, 'Pose de parquet - Revetement de sol', 5, 'Pose de parquet', 8, 5, 40, 18);
insert into services
values (4, 'Carrelage', 2, 'Carrelage', 25, 24, 13, 18);
insert into services
values (5, 'Chaudronnerie - Soudure', 1, 'Chaudronnerie', 26, 9, 19, 18);
insert into services
values (6, 'Charpente', 89, 'Charpente', 14, 22, 49, 1);
insert into services
values (7, 'Chauffage - Climatisation', 10, 'Chauffage', 6, 17, 43, 18);
insert into services
values (8, 'Couverture - Toiture', 11, 'Toiture', 16, 15, 50, 1);
insert into services
values (9, 'Installation electrique', 15, 'electrique', 17, 8, 47, 1);
insert into services
values (10, 'Maconnerie', 12, 'Maconnerie', 18, 27, 12, 1);
insert into services
values (11, 'Terrassement - Assainissement', 20, 'Assainissement', 5, 25, 29, 1);
insert into services
values (12, 'Menuiserie - Huisserie - Agencement', 24, 'Huisserie', 1, 11, 32, 1);
insert into services
values (13, 'Peinture - Tapisserie', 26, 'Tapisserie', 3, 12, 45, 24);
insert into services
values (14, 'Platrerie - Murs - Plafonds', 123, 'Murs', 4, 16, 17, 1);
insert into services
values (15, 'Plomberie - Installation sanitaire', 12, 'Installation sanitaire', 19, 14, 20, 1);
insert into services
values (16, 'Ramonage - Fumiste', 11, 'Fumiste', 23, 19, 35, 1);
insert into services
values (17, 'Architecte - Maitre oeuvre', 29, 'Maitre oeuvre', 13, 23, 18, 1);
insert into services
values (18, 'Serrurerie', 15, 'Serrurerie', 9, 4, 42, 18);
insert into services
values (19, 'Artisan tout corps d etat - Renovation', 20, 'Artisan', 27, 6, 26, 18);
insert into services
values (20, 'Taille de pierre - Marbrerie', 30, 'Marbrerie', 10, 20, 9, 18);
insert into services
values (21, 'Architecte interieur - Decorateur interieur', 35, 'Decorateur interieur', 22, 1, 11, 1);
insert into services
values (22, 'Artisan art', 24, 'Artisan art', 21, 21, 16, 18);

insert into publicite (idPublicite, description, idAdministrateur)
values (1,
        'En avant les architectes ! C’est la semaine de l’architecture ! Aménagements, décoration, ameublement… découvrez de belles réalisations et trouvez l’inspiration !',
        2);
insert into publicite (idPublicite, description, idAdministrateur)
values (2,
        'Faites découvrir AlloVoisins à vos proches. En les invitant, vous contribuez à agrandir la communauté d’habitants et de professionnels de nos quartiers.',
        14);
insert into publicite (idPublicite, description, idAdministrateur)
values (3,
        'Réalisez vos projets ! Retrouvez d"un coup d"œil toutes les prestations de services et locations de matériel dédiées à votre besoin du moment !',
        48);
insert into publicite (idPublicite, description, idAdministrateur)
values (4,
        'Le paiement par carte bancaire disponible partout sur AlloVoisins. Découvrez les dernières nouveautés du paiement par carte bancaire sur AlloVoisins !',
        38);
insert into publicite (idPublicite, description, idAdministrateur)
values (5,
        'Réalisez vos projets ! Retrouvez d"un coup d"œil toutes les prestations de services et locations de matériel dédiées à votre besoin du moment !',
        31);
insert into publicite (idPublicite, description, idAdministrateur)
values (6, 'Une belle pelouse pour le Printemps ! Thomas vous donne ses astuces de jardinage pour le Printemps !', 40);
insert into publicite (idPublicite, description, idAdministrateur)
values (7,
        'Gagnez 3 abris à insectes pour votre jardin ! Pour participer, il vous suffit de liker, commenter et partager cette publication avant le vendredi 25 mars, 18h. 3 gagnants seront alors tirés au sort.',
        20);
insert into publicite (idPublicite, description, idAdministrateur)
values (8,
        'Une Astuce à partager ? Chaque semaine, nous partageons en vidéos les meilleures Astuces de Voisins. Proposez-nous la vôtre !',
        27);
insert into publicite (idPublicite, description, idAdministrateur)
values (9,
        'Préparez le Printemps ! Entretien du jardin après la période hivernale, travaux extérieurs, semences et plantations dans le potager, élagage',
        2);
insert into publicite (idPublicite, description, idAdministrateur)
values (10,
        'Des salles d’eau inspirantes ! C’est la journée mondiale de la plomberie ! Trouvez l’inspiration parmi une sélection de salles d’eau !',
        43);

insert into favoris
values (1, 49, 29);
insert into favoris
values (2, 31, 18);
insert into favoris
values (3, 41, 45);
insert into favoris
values (4, 39, 11);
insert into favoris
values (5, 12, 3);
insert into favoris
values (6, 18, 18);
insert into favoris
values (7, 46, 40);
insert into favoris
values (8, 12, 26);
insert into favoris
values (9, 41, 14);
insert into favoris
values (10, 5, 32);
insert into favoris
values (11, 44, 14);
insert into favoris
values (12, 44, 23);
insert into favoris
values (13, 39, 35);
insert into favoris
values (14, 24, 20);
insert into favoris
values (15, 44, 49);
insert into favoris
values (16, 41, 49);
insert into favoris
values (17, 49, 50);
insert into favoris
values (18, 7, 20);
insert into favoris
values (19, 24, 43);
insert into favoris
values (20, 3, 47);
insert into favoris
values (21, 15, 26);
insert into favoris
values (22, 18, 11);
insert into favoris
values (23, 4, 40);
insert into favoris
values (24, 27, 12);
insert into favoris
values (25, 39, 26);
insert into favoris
values (26, 46, 9);
insert into favoris
values (27, 27, 9);
insert into favoris
values (28, 34, 46);
insert into favoris
values (29, 8, 37);
insert into favoris
values (30, 3, 43);
insert into favoris
values (31, 46, 47);
insert into favoris
values (32, 24, 16);
insert into favoris
values (33, 25, 46);
insert into favoris
values (34, 27, 49);
insert into favoris
values (35, 26, 26);



insert into demande
values (1,
        'Recherche Bricolage - Petits travaux a Lancon Provence. Bonjour, Je recherche un installateur de motorisation solaire pour portail',
        20, 1);
insert into demande
values (2,
        'Location local stockage / garde meuble / local entreposage - Marseille 6e Arrondissement. Bonjour, je cherche un box pour quelques cartons et petits meubles',
        50, 2);
insert into demande
values (3,
        'Recherche Plomberie - Installation sanitaire - Plombieres Les Dijon. Bonjour, je cherche quelqu"un qui pourrait me refaire le joint de ma douche',
        30, 3);
insert into demande
values (4,
        'Cherche Bricolage - Petits travaux a Massy. Bonjour, J"ai besoin de quelqu"un pour poser des tringles',
        62, 4);
insert into demande
values (5,
        'Cherche Terrassement - Assainissement - Illiers Combray. Bonjour, conbien couteres pour retourner 60m3 de terre',
        5, 5);
insert into demande
values (6,
        'Cherche Bricolage - Petits travaux a Maubeuge. Bonjour, j"ai  besoin  de quelqun qui peux menter un', 9, 6);
insert into demande
values (7, 'Louer une tondeuse a gazon - Avord. Bonjour, je cherche une Tondeuse a gazon. Merci.', 15, 7);
insert into demande
values (8,
        'Cherche Jardinier a Lanvallay. Bonjour, je cherche sur Dinan/Lanvallay une aide pour entretenir jardin ,allees, pelouses',
        17, 8);
insert into demande
values (9,
        'Recherche Reparation outillage a Harnes. Bonjour, le ressort d"entrainement des roues de ma tondeuse a gazon est a remplacer. Quelqu"un a t-il des connaissances pour reparer ? Merci',
        25, 9);
insert into demande
values (10,
        'Cherche Femme de Menage a Leran. Bonjour, Employeur particulier Cesu recherche personne serieuse et avec experience de preference pour effectuer 2 heures de menage par semaine.',
        12, 10);
insert into demande
values (11,
        'Acheter une palette - Pithiviers. Bonjour, je cherche quelqu un qui pourrait me debarrasser le jardin j ai des palette je les donne et enlever des jouets qui serve plus et des panneaux en bois',
        1, 11);
insert into demande
values (12,
        'Cherche Installation electrique a Chalons En Champagne. Bonjour, nous recherchons pour une maison que nous venons d"acheter sur Suippes une personne avec de tres bonnes competences en electricite.',
        100, 12);
insert into demande
values (13,
        'Recherche Femme de Menage a Orleans. Bonjour, je cherche une femme de menage qui sache tres bien repasser 2 ou 3 h par semaine.',
        12, 13);
insert into demande
values (14,
        'Recherche Reparation voiture a Plaisance Du Touch. Bonjour, je recherche un mecanicien  dans perimetre de Fonsorbes , plaisance faisant reparations',
        26, 14);
insert into demande
values (15,
        'Recherche Restauration chez l"habitant a Frejus. Bonjour, cherche barista free lance pour 1 journee de formation machine espresso semi-pro nuevo simonelli musica 1 groupe, pratique mousse de lait.',
        35, 15);
insert into demande
values (16,
        'Cherche Taille de haies et d"arbustes a Saint Pompain. Bonjour, je recherche une personne qui dispose d"un tracteur avec taille haie pour realiser la coupe de mes thuyaux',
        23, 16);
insert into demande
values (17,
        'Cherche Plomberie - Installation sanitaire a Pont L Abbe. Bonjour, je cherche une personne pour changer de la tuyauterie. Merci.',
        15, 17);
insert into demande
values (18,
        'Cherche Demenagement a Cerny. Bonjour, je recherche une personne avec un camion pour transporter une bibliotheque en bois massif.',
        26, 18);
insert into demande
values (19,
        'Recherche Jardinier a La Foret Fouesnant. Bonjour, Je suis a la recherche d"une personne pouvant m"aider a nettoyer et a preparer la terre pour un potager.',
        89, 19);
insert into demande
values (20,
        'Recherche Estheticienne a Epone. Bonjour, je cherche une estheticienne a domicile pour soins des pieds.', 32,
        20);
insert into demande
values (21,
        'Cherche Tonte de pelouse - Debroussaillage a Lyon 3e Arrondissement. Bonjour, je cherche une personne pour nettoyer mon terrain. Merci.',
        24, 21);
insert into demande
values (22,
        'Cherche Jardinier a Lyon 3e Arrondissement. Bonjour, je cherche une personne pour becher mon jardin. Merci.',
        24, 22);
insert into demande
values (23,
        'Cherche Taille de pierre - Marbrerie a Halluin. Bonjour, Il y aurait une personne qui renove du marbre. C"est pour une table bistrot. Merci',
        10, 23);
insert into demande
values (24,
        'Cherche Reparation voiture a Bruges. Bonjour, je cherche  quelqu"un pour permuter les pneus arrieres a l avant et monter des neufs a l arriere sur une Renault lagune 3',
        21, 24);
insert into demande
values (25,
        'Cherche Reparation voiture a Le Mans. Bonjour, mecano pour aider changer moteur Megane essence avec une chevre',
        8, 25);
insert into demande
values (26,
        'Recherche Femme de Menage a Tende. Bonjour, je recherche une personne serieuse pour 2 heures de menage  par semaine a Saint Dalmas de Tende',
        15, 26);
insert into demande
values (27,
        'Location rouleau a gazon - Pournoy La Grasse. Bonjour, j aurais besoin d un rouleau pour gazon merci', 10, 27);
insert into demande
values (28,
        'Louer une surfaceuse ponceuse de sol - Serignac Sur Garonne. Bonjour, je cherche une ponceuse sol exterieur pour terrasse',
        41, 28);
insert into demande
values (29,
        'Recherche Installation electrique a Athis-Mons. Bonjour, Je suis a la recherche d"un electricien, pour renovation complete Disponible rapidement Je vous remercie',
        45, 29);